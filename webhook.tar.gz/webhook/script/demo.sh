#!/bin/bash

sleep 10

echo "push 10 seconds ago"